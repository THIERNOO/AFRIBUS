<?php

$this->load->view('Templates/header');
$this->load->view($page_name);
$this->load->view('Templates/footer');

?>