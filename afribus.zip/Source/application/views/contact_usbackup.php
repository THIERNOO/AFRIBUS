<div class="col-lg-12 myTabContent" id="myTabContent">              		 			 		                           								 		                   <div class="col-lg-6">								 
 <p class="hed_fiel">Your Name*</p>                    
 <input  name="name" required type="text" class="fields" id="name12" placeholder="Your Name">
 <p class="hed_fiel">Phone</p>                      
 <input name="phone" type="text" class="fields" required id="name12" placeholder="Phone"></div>	
 <div class="col-lg-6"> 
<p class="hed_fiel">Suggestion / Feedback*</p>		
 
<input name="message" type="textareas words" required class="fields" >  
<p class="hed_fiel">email*</p>	 <input name="email" type="email"required class="fields" > 
<p><input class="findtaxibtn sel_taxi movestep2" type="button" id="button"value="Submit"></p> 
 </div>	

	      
 </div>
 <div class="col-lg-6">   <p>Techware Solution, Heavenly Plaza
ES&FS 7th Floor,Kakkanad, Cochin,
Kerala – 682021  or contact us by sending us mail on support@site.in</p><br></div>