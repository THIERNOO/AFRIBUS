<!--payment-->

<div class="container-fluid" style="background: #eeeeee;">

<div class="container">

    <div class="col-lg-2"></div>

    <div class="col-lg-8">



        <div class="row pay-wallet success-mn">

            <div class="col-lg-6">

        <h3 class="success-h3"><span><img src="<?php echo base_url();?>assets/img/payment/3.png" /></span>Add to Wallet</h3>

            </div>

            <div class="col-lg-6">

                <h3 class="success-h3-1"><strong class="str-success">Your Transaction ID is </strong> <?php echo $book_info->uneaque_id; ?></h3>

            </div>

        </div>





                      <div class="row">

                          <div class="col-lg-12">

                              <div class="left-success" style=" border-right: 0 solid #c6c6c6;">

                              <h3>Thank You for using Wallet</h3>

                                  

                                  <h5>Total Amount Payable<span><?php echo $book_info->amount; ?>/-</span></h5>

                              </div>

                          </div>

                          

                      </div>







    </div>

    <div class="col-lg-2"></div>

</div>



</div>



<!--payment-->



